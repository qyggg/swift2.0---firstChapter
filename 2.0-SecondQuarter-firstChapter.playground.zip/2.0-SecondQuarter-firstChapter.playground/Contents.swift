//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


//2018-10-15
//-----------------------------------🔴-swift2.0(第二季)1-1,Swift2.0 为什么要有可选型--------------------------------------

/*⚠️
 什么是可选型Optional,
 既可以表示某一具体的类型,也可以表示空
 
 swift语言中没有不代表是0,没有就是没有
 
 nil本身是一个特殊的类型,需要与其他类型一起共存
 */

var errorCode: Int = 404
errorCode = 0


//加上问号时代表整型的可选型,代表errorCode2的变量中可以赋上整型也可以赋上nil ⚠️
var errorCode2: Int? = 404


//errorCode = nil ❌
//var color: UIColor = nil ❌
var color: UIColor? = nil


//可选型可以赋上整型,但整型不能赋上可选型 ⚠️
let imInt = 405
errorCode2 = imInt
//imInt= errorCode2 ❌

print(errorCode2)

//如果要使变量成为可选型,必须显式声明,一般用变量声明 var ⚠️

//let imOptional = nil ❌
let imOptional: String? = "hello"


//------------------------------------🔴-swift2.0(第二季)1-2,Swift2.0 可选型的解包--------------------------------------


var errorCode3: String? = "404"
print(errorCode3)

//可选型是不能被直接使用的 ⚠️
//"The errorCode is" + errorCode3 ❌

// Unwrap 解包 ⚠️
//强制解包:在可选型变量后面加上"!",但强制解包有风险(可选型变量为空时)
"The errorCode is" + errorCode3!


if errorCode3 != nil{
  "The errorCode is" + errorCode3!
}
else
{
    "No error"
}




//此处 unwrappedErrorCode 为解包后的变量值

//此处也可声明为var ,变量名也可为可选型变量名

//if var errorCode3 = errorCode3 ,但解包后的 errorCode3 仅限花括号内使用
if let unwrappedErrorCode = errorCode3
{
     "The errorCode is" + unwrappedErrorCode
}
else
{
"No error"
}



var errorMessage: String? = "Not found"

if let errorCode3 = errorCode3
{
    if let errorMessage = errorMessage {
        "The errorCode is" + errorCode3 + "\nThe errorMessage is" + errorMessage
    }
}


//一次解包多个可选型变量,用逗号隔开
if let errorCode3 = errorCode3,
    let errorMessage = errorMessage
{
    "The errorCode is" + errorCode3 + "\nThe errorMessage is" + errorMessage

}




// 此种写法在2.0适用 ⚠️
/*
if let errorCode3 = errorCode3,
     errorMessage = errorMessage where  errorCode3 == "404"
    
{
    print("page not found")
}
*/


if let errorCode3 = errorCode3, errorCode3 == "404",
   let errorMessage = errorMessage
   
{
    print("page not found")
}

//------------------------------------🔴-swift2.0(第二季)1-3,Swift2.0 Optional Chaining 和 Nil-Coalesce--------------------------------------
var errorMessage2: String? = "Not Found"
if let errorMessage2 = errorMessage2 {
    errorMessage2.uppercased() // uppercased() 字符转大写

}

//errorMessage2.uppercased() ❌
errorMessage2?.uppercased()
errorMessage2!.uppercased()  //当errorMessage2 = nil时 报错,所以此种写法不安全

var uppercaseErrorMessage = errorMessage2?.uppercased() //可选型

if let errorMessage2 = errorMessage2?.uppercased()
{
    errorMessage2
}


/*
 nil coalesce
 
 三种写法
 */
var errorMessage3: String? = nil

let message3: String
if let errorMessage3 = errorMessage3 {
    message3 = errorMessage3
}
else
{
    message3 = "No error"
}


let message4 = errorMessage3 == nil ? "No error" : errorMessage3


let message5 = errorMessage3 ?? "No error"


//------------------------------------🔴-swift2.0(第二季)1-4,Swift2.0 更多可选型的实际使用--------------------------------------
/*
 可选型在元组中的使用 ⚠️
 */

//元组中的一个为可选型
var error4: (errorCode4 :Int ,errorMessage4: String?) = (404,"Not Found")

error4.errorMessage4 = nil
error4
//error4 = nil  ❌   无法把nil赋给一个非可选型的类型



// 整个元组为可选型
var error5: (errorCode5 :Int ,errorMessage5: String)? = (404,"Not Found")
//error5?.errorMessage5 = nil ❌
error5 = nil


var error6: (errorCode6 :Int ,errorMessage6: String?)? = (404,"Not Found")

/*
 可选型的实际应用 ⚠️
 */

var ageInput: String = "xyz"
var age = Int(ageInput)

if let age = Int(ageInput) ,age < 20{
    print("You are a teenager")
}


var greetings = "Hello"

//greetings.range(of: "ll")
//greetings.rangeOfSt(from: "ll")

/*
 3.0中不能用了 ⚠️
greetings.rangeOfString("ll")
greetings.rangeOfString("oo")
*/

//// control + command + 空格  输入表情 ⚠️

//------------------------------------🔴-swift2.0(第二季)1-5,Swift2.0 隐式可选型--------------------------------------

/*
 隐式可选型
 主要用于类中
 */

var errorMessage7: String? = nil

errorMessage7 = "Not found"
"The message is" + errorMessage7!  //叹号强制解包


//一个类型后面接叹号,此种类型也是可以即存 nil 又存具体的类型,区别在于当我们具体使用的时候可以不对其进行解包
//此种类型为隐式可选型,可以存放nil,但在其使用的时候可以不解包
//这样的可选型其实是危险的,(因为它可以存放nil,使用的时候又可直接使用),容易产生程序的崩溃
var errorMessage8: String! = nil

errorMessage8 = "Not found"
"The message is" + errorMessage8


//例子未写⚠️⚠️⚠️
//class City
//{
//    let cityName: String
//    var country: Country
//    init(cityName: String, country: Country) {
//        self.cityName = cityName
//        self.country = country
//    }
//
//}
















